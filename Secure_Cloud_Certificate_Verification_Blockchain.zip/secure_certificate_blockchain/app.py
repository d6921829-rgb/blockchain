import os, sqlite3, hashlib, json, uuid
from datetime import datetime, timezone
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session, send_from_directory
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash

ROOT = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(ROOT, "certificates.db")
UPLOAD_DIR = os.path.join(ROOT, "uploads")
ALLOWED_EXTENSIONS = {"pdf"}
MAX_BYTES = 10 * 1024 * 1024

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-before-deployment")
app.config["MAX_CONTENT_LENGTH"] = MAX_BYTES
os.makedirs(UPLOAD_DIR, exist_ok=True)

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL, role TEXT NOT NULL)""")
        con.execute("""CREATE TABLE IF NOT EXISTS blocks (
            id INTEGER PRIMARY KEY AUTOINCREMENT, block_index INTEGER UNIQUE NOT NULL,
            timestamp TEXT NOT NULL, certificate_id TEXT UNIQUE NOT NULL,
            file_hash TEXT NOT NULL, student_name TEXT NOT NULL, course TEXT NOT NULL,
            issuer TEXT NOT NULL, previous_hash TEXT NOT NULL, block_hash TEXT NOT NULL)""")
        # Demo issuer account. Change this password before using beyond a demo.
        if not con.execute("SELECT id FROM users WHERE username='issuer'").fetchone():
            con.execute("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",
                        ("issuer", generate_password_hash(os.environ.get("DEMO_PASSWORD", "ChangeMe123!")), "issuer"))

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

def latest_hash(con):
    row = con.execute("SELECT block_hash FROM blocks ORDER BY block_index DESC LIMIT 1").fetchone()
    return row["block_hash"] if row else "0" * 64

def calculate_block_hash(payload):
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(raw).hexdigest()

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("user_id"):
            flash("Please sign in as an issuer first.", "warning")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapped

@app.route("/")
def index():
    with db() as con:
        count = con.execute("SELECT COUNT(*) n FROM blocks").fetchone()["n"]
    return render_template("index.html", count=count)

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        with db() as con:
            user = con.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session["user_id"], session["username"] = user["id"], user["username"]
            return redirect(url_for("dashboard"))
        flash("Invalid username or password.", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/dashboard")
@login_required
def dashboard():
    with db() as con:
        rows = con.execute("SELECT * FROM blocks ORDER BY block_index DESC").fetchall()
    return render_template("dashboard.html", blocks=rows)

@app.route("/issue", methods=["POST"])
@login_required
def issue():
    student = request.form.get("student_name", "").strip()
    course = request.form.get("course", "").strip()
    file = request.files.get("certificate")
    if not student or not course or not file or not file.filename:
        flash("Enter student name, course and choose a PDF certificate.", "danger")
        return redirect(url_for("dashboard"))
    if not file.filename.lower().endswith(".pdf"):
        flash("Only PDF files are accepted.", "danger")
        return redirect(url_for("dashboard"))
    # Verify PDF signature, not only the extension.
    data = file.read()
    if not data.startswith(b"%PDF"):
        flash("The uploaded file does not appear to be a valid PDF.", "danger")
        return redirect(url_for("dashboard"))
    file.seek(0)
    cert_id = str(uuid.uuid4()).upper()
    safe_name = secure_filename(file.filename) or "certificate.pdf"
    stored_name = cert_id + "_" + safe_name
    path = os.path.join(UPLOAD_DIR, stored_name)
    file.save(path)
    file_hash = sha256_file(path)
    timestamp = datetime.now(timezone.utc).isoformat()
    with db() as con:
        prev = latest_hash(con)
        idx = con.execute("SELECT COALESCE(MAX(block_index),0)+1 n FROM blocks").fetchone()["n"]
        payload = {"block_index": idx, "timestamp": timestamp, "certificate_id": cert_id,
                   "file_hash": file_hash, "student_name": student, "course": course,
                   "issuer": session["username"], "previous_hash": prev}
        block_hash = calculate_block_hash(payload)
        con.execute("""INSERT INTO blocks(block_index,timestamp,certificate_id,file_hash,
                    student_name,course,issuer,previous_hash,block_hash)
                    VALUES(?,?,?,?,?,?,?,?,?)""",
                    (idx,timestamp,cert_id,file_hash,student,course,session["username"],prev,block_hash))
    flash(f"Certificate issued. Verification ID: {cert_id}", "success")
    return redirect(url_for("dashboard"))

@app.route("/verify", methods=["GET", "POST"])
def verify():
    result = None
    if request.method == "POST":
        cert_id = request.form.get("certificate_id", "").strip().upper()
        uploaded = request.files.get("certificate")
        with db() as con:
            row = con.execute("SELECT * FROM blocks WHERE certificate_id=?", (cert_id,)).fetchone()
        if not row:
            result = {"valid": False, "message": "No certificate with that verification ID was found."}
        elif uploaded and uploaded.filename:
            data = uploaded.read()
            digest = hashlib.sha256(data).hexdigest()
            valid = digest == row["file_hash"]
            result = {"valid": valid, "message": "Certificate is authentic and unchanged." if valid else
                      "File hash does not match. The file may have been modified or is not the original.",
                      "student": row["student_name"], "course": row["course"], "issuer": row["issuer"],
                      "timestamp": row["timestamp"], "block_hash": row["block_hash"]}
        else:
            result = {"valid": True, "message": "Verification ID exists in the ledger. Upload the PDF to verify its contents.",
                      "student": row["student_name"], "course": row["course"], "issuer": row["issuer"],
                      "timestamp": row["timestamp"], "block_hash": row["block_hash"], "id_only": True}
    return render_template("verify.html", result=result)

@app.route("/api/verify", methods=["POST"])
def api_verify():
    cert_id = request.form.get("certificate_id", "").strip().upper()
    uploaded = request.files.get("certificate")
    with db() as con:
        row = con.execute("SELECT * FROM blocks WHERE certificate_id=?", (cert_id,)).fetchone()
    if not row:
        return jsonify({"valid": False, "message": "Verification ID not found"}), 404
    if not uploaded:
        return jsonify({"valid": None, "message": "ID exists; upload the PDF to check its hash"}), 200
    digest = hashlib.sha256(uploaded.read()).hexdigest()
    return jsonify({"valid": digest == row["file_hash"], "student": row["student_name"],
                    "course": row["course"], "issuer": row["issuer"],
                    "file_hash": row["file_hash"], "block_hash": row["block_hash"]})

@app.route("/ledger")
def ledger():
    with db() as con:
        rows = con.execute("SELECT block_index, timestamp, certificate_id, file_hash, previous_hash, block_hash FROM blocks ORDER BY block_index").fetchall()
    return render_template("ledger.html", blocks=rows)

@app.route("/uploads/<path:filename>")
@login_required
def private_upload(filename):
    return send_from_directory(UPLOAD_DIR, filename, as_attachment=True)

@app.errorhandler(413)
def too_large(_):
    flash("File is too large. Maximum upload size is 10 MB.", "danger")
    return redirect(request.referrer or url_for("index"))

init_db()
if __name__ == "__main__":
    app.run(debug=True)
