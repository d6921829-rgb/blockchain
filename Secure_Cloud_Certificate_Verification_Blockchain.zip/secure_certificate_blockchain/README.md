# Secure Cloud Certificate Verification Using Blockchain

A beginner-friendly full-stack project built with **Python Flask**, **HTML/CSS/JavaScript-ready frontend templates**, and **SQLite**. It demonstrates certificate issuance and verification using SHA-256 file fingerprints and a hash-linked ledger.

## Features
- Issuer login and protected dashboard
- Issue certificates by uploading PDF files
- Unique verification ID for every issued certificate
- SHA-256 fingerprint of the exact uploaded PDF
- Append-only, hash-linked ledger records
- Public verification page (ID + original PDF)
- Public ledger view showing hashes, not private PDF files
- JSON verification endpoint: `POST /api/verify`

## Requirements
- Python 3.10 or newer
- pip

## Run on Windows
1. Extract the ZIP.
2. Open the extracted folder in VS Code.
3. Open Terminal in VS Code and run:

```bash
python -m venv venv
venv\\Scripts\\activate
pip install -r requirements.txt
python app.py
```

4. Open `http://127.0.0.1:5000` in your browser.
5. Demo issuer login:
   - Username: `issuer`
   - Password: `ChangeMe123!`

Change the demo password before using this outside a classroom demo. Set environment variables `SECRET_KEY` and `DEMO_PASSWORD` before first run for a safer setup. The default demo account is created automatically if it does not exist.

## How to test
1. Sign in to the issuer portal.
2. Enter a recipient name and course, then upload a real PDF certificate.
3. Copy the generated verification ID from the success message.
4. Open **Verify**, paste the ID, upload the exact same PDF, and submit.
5. Try a different or modified PDF with the same ID; the hash comparison should fail.
6. Open **Ledger** to view linked block hashes.

## Project structure

```text
secure_certificate_blockchain/
├── app.py
├── requirements.txt
├── README.md
├── .env.example
├── .gitignore
├── certificates.db       # created automatically on first run
├── uploads/              # uploaded PDFs (private)
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── login.html
│   ├── dashboard.html
│   ├── verify.html
│   └── ledger.html
└── static/
    └── style.css
```

## API
`POST /api/verify` as multipart form data:
- `certificate_id`: verification ID
- `certificate`: PDF file (optional; when supplied, its SHA-256 is checked)

## Important project scope and security notes
- This is an **educational blockchain-inspired prototype**, not a production public blockchain. It uses a single SQLite database and a hash chain; a database administrator could alter the database and recompute hashes.
- "Cloud" in the project title describes the intended deployment concept. This ZIP runs locally. To make it a cloud-hosted system, deploy the Flask app to a secure hosting provider and use managed storage/database.
- For real deployment: use HTTPS, a strong secret, secure password provisioning, role-based user administration, CSRF protection, rate limiting, malware scanning, private object storage, backups, audit monitoring, and an independently operated blockchain or permissioned network.
- Never upload real personal certificates to an untrusted demo server.
